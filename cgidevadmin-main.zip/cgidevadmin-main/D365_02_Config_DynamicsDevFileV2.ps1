Clear-Host;

#Load assamblies
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName('MSystem.Drawing') | Out-Null

$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  

#Script version
$Script:Version = '2.0.0';
   
#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\ConfigDynamicsDev_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

# Get path to file
$Script:ConfigurationFile = Get-ItemProperty -Path HKCU:\SOFTWARE\Microsoft\Dynamics\AX7\Development\Configurations

Write-Output ("============================== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Config DynamicsDevConfig file                  =")
Write-Output ("==================================================")
Write-Output ("Script version is ....: {0}" -f $Script:Version)
Write-Output ("Config-file is .......: {0}" -f $Script:ConfigurationFile.Name)

try {
    if (!$Script:ConfigurationFile) {
        throw ("Configuration file '{0}'is not created, setup Visual Studio first !" -f $Script:ConfigurationFile.DefaultConfig)
    }
    else {
        #region begin formdesign

        $form = New-Object 'System.Windows.Forms.Form';$form.Width = 590;$form.Height = 250;$form.Text = 'Please enter following values';$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen;

        ##############Define text label1
        $textLabel1 = New-Object 'System.Windows.Forms.Label';$textLabel1.Left =  25;$textLabel1.Top = 30;$textLabel1.Text = 'Default company';
        $textBox1   = New-Object 'System.Windows.Forms.TextBox';$textBox1.Left = 150;$textBox1.Top   = 30;$textBox1.width  = 400;
        ##############Define text label2
        $textLabel2 = New-Object 'System.Windows.Forms.Label';$textLabel2.Left =  25;$textLabel2.Top = 70;$textLabel2.Text = 'Default model';
        $textBox2   = New-Object 'System.Windows.Forms.TextBox';$textBox2.Left = 150;$textBox2.Top   = 70;$textBox2.width  = 400;
        ##############Define text label3
        $textLabel3 = New-Object 'System.Windows.Forms.Label';$textLabel3.Left =  25;$textLabel3.Top =110;$textLabel3.Text = 'Offline Admin email';
        $textBox3   = New-Object 'System.Windows.Forms.TextBox';$textBox3.Left = 150;$textBox3.Top   =110;$textBox3.width  = 400;
        ##############Define text label4
        $textLabel4 = New-Object 'System.Windows.Forms.Label';$textLabel4.Left =  25;$textLabel4.Top =150;$textLabel4.Text = 'Sync DB in Build';
        $textBox4   = New-Object 'System.Windows.FormsTextBox';$textBox4.Left  = 150;$textBox4.Top   =150;$textBox4.width   = 400;

        #############Define default values for the input boxes
        $defaultValue = ''
        $textBox1.Text = $defaultValue;
        $textBox2.Text = $defaultValue;
        $textBox3.Text = $defaultValue;
        $textBox4.Text = $true;

        #############define button
        $button = New-Object 'System.Windows.Forms.Button';
        $button.Left  = 450;
        $button.Top   = 180;
        $button.Width = 100;
        $button.Text  = 'Enter';

        ############# This is when you have to close the form after getting values
        $eventHandler = [System.EventHandler] {
        $textBox1.Text;
        $textBox2.Text;
        $textBox3.Text;
        $textBox4.Text;
        $form.Close();
        };

        $button.Add_Click($eventHandler) ;

        #############Add controls to all the above objects defined
        $form.Controls.Add($textLabel1);
        $form.Controls.Add($textBox1);
        $form.Controls.Add($textLabel2);
        $form.Controls.Add($textBox2);
        $form.Controls.Add($textLabel3);
        $form.Controls.Add($textBox3);
        $form.Controls.Add($textLabel4);
        $form.Controls.Add($textBox4);
        $form.Controls.Add($button);
        $form.ShowDialog();

        #################return values
        $DefaultCompany = $textBox1.Text
        $DefaultModel   = $textBox2.Text
        $AdminEmail     = $textBox3.Text
        $DBSyncInBuild  = $textBox4.Text

        #endregion        

        #$DefaultCompany = [Microsoft.VisualBasic.Interaction]::InputBox(“Enter Default company”, “Default company”)
        #$DefaultModel   = [Microsoft.VisualBasic.Interaction]::InputBox(“Enter Default model”, “Default model”)
        #$AdminEmail     = [Microsoft.VisualBasic.Interaction]::InputBox(“Enter your email”, “Offline Admin email”)
        
        If (!$DefaultCompany) {
            throw "Value for default company is missing !"
        }

        If (!$DefaultModel) {
            throw "Value for default model is missing !"
        }

        If (!$AdminEmail) {
            throw "Email is missing !"
        }

        if ($AdminEmail -match '/^([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6})*$/' -eq $false) {
            throw "Wrong format on the email"
        }

        [xml]$configuration = (Get-Content $Script:ConfigurationFile.DefaultConfig)
        $xmlProperty =  $configuration.ChildNodes #SelectNodes("//*")
        foreach($property in $xmlProperty.ChildNodes) #$xmlProperty)
        {
	        switch($property.name)
	        {
		        "OrganizeElementsInProject" 
		        {
			        $property.InnerText="true"
		        }
		        "DefaultWebBrowser"
		        {
			        $property.InnerText="Google Chrome"
                    $property.RemoveAllAttributes()
  		        }
                "DefaultCompany"
                {
                    $property.InnerText = $DefaultCompany
                }
                "DefaultModelForNewProjects"
                {
                    $property.InnerText = $DefaultModel
                }
                "OfflineAuthenticationAdminEmail"
                {
                    $property.InnerText = $AdminEmail
                }
                "DBSyncInBuild"
                {
                    $property.InnerText = $DBSyncInBuild
                }

	        }
        }
        $configuration.save($Script:ConfigurationFile.DefaultConfig)
    }
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    Start-Sleep 4    
}
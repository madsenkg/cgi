#Requires -RunAsAdministrator
Clear-Host;

#Script version
$Script:Version = '1.0.4';

#Init Variables
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;

[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
[String]$DbName = ("AxDB_{0}" -f (Get-Date -Format MMMddHH))

Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\RestoreAxDBBacpac_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

#Install AzCopy
Invoke-D365InstallAzCopy -Path "C:\Windows\System32\AzCopy.exe"
Invoke-D365InstallSqlPackage -Path "C:\Windows\System32\SqlPackage.exe"

# Get Sqlserver information
$Sql = Get-DbaDefaultPath -SqlInstance .

try {
    Write-Output ("============================== {0} ====" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
    Write-Output ("= Download file from Asset Libray and Restore AxDB =")
    Write-Output ("====================================================")
    Write-Output ("Script version is.....: {0}" -f $Script:Version)
    Write-Output ("SQL Server Instance...: {0}" -f $sql.SqlInstance)
    Write-Output ("Backup is restored as : {0}" -f $DbName)
    Write-Output ("Backup folder is .....: {0}" -f $sql.Backup)
    Write-Output ("====================================================")
    $SASlink = [Microsoft.VisualBasic.Interaction]::InputBox("SAS Link", "Enter the SAS Link from LCS")
    
    if (!$SASLink) {
        write-output "No SAS link found"
        exit
    }
    
    Write-Output ("Downloading : {0}" -f $SASLink)
    Start-Process azcopy.exe -Wait -WindowStyle Normal -ArgumentList "copy", $SASlink, (Join-Path $sql.Backup $DBName".bacpac")

    $Bacpacfile = Get-ChildItem -Path $sql.Backup -Filter *.bacpac | Sort-Object LastWriteTime  | Select-Object -last 1

    if (!$Bacpacfile) {
        throw "Backup file not found !"
    }

    Write-Output ("Restore file : '{0}'" -f $Bacpacfile.Fullname)
    Write-Output ("====================================================")
    
    Write-Output "Stopping all services..."
    Stop-D365Environment -All
    
    Write-Output "Removing the old original database..."
    Remove-D365Database -DatabaseName AxDB_original -WarningAction Ignore

    Write-Output "Importing database..."
    d365fo.tools\Import-D365Bacpac -ImportModeTier1 -BacpacFile $Bacpacfile.FullName -NewDatabaseName $DbName -ShowOriginalProgress

    Write-Output "Switching to the imported database..."
    Switch-D365ActiveDatabase -NewDatabaseName $DbName

    Write-Output "Removing the previous original database..."
    Remove-D365Database -DatabaseName AxDB_original -WarningAction Ignore

    Write-Output "Update sysglobalconfiguration..."
    Invoke-D365SqlCmd -Command "UPDATE sysglobalconfiguration set value = 'SQLSERVER' where name = 'BACKENDDB'"
    Invoke-D365SqlCmd -Command "UPDATE sysglobalconfiguration set value = '0' where name = 'TEMPTABLEINAXDB'" 

    Write-Output "Starting the services..."
    Start-D365Environment

    Start-Sleep -Seconds 180

    Write-Output "Synchronize AXDB..."
    Invoke-D365DBSync -Verbosity Detailed -ShowOriginalProgress -LogPath "Logs"
}

catch {
    Write-Output "Something went wrong !"
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    if ($Bacpacfile) {
        Write-Output "Remove bacpac file from backup folder"
        Remove-Item -Path $Bacpacfile.FullName -force -WarningAction SilentlyContinue  
    }

    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."
    Stop-Transcript 
    Start-Sleep 5
}

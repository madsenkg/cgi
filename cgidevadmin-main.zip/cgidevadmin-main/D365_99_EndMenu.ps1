﻿$Global:EndMenu = $true
Write-Output ""
Write-Output "Ending menu..."
start-sleep 2
# cloudhostedvm
General Developer Setup for Cloud Hosted Environments in LCS

#Requires -RunAsAdministrator
Clear-Host;

#Filter on files with prefix D365_
function showmenu { 
   $prg = menu (Get-ChildItem -Filter D365_*.ps1) 
   Invoke-Expression ".//$prg"
 }

#Init Variables
$Global:EndMenu   = $false
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Load-Powershell-modules
Write-Output "Loading modules.. please wait..."
.\_D365_Load_Modules.ps1

#Run the menu
 Do {
    Clear-Host;

    Write-Output "D365fo Developer Administration Menu"
    Write-Output "===================================="

    showmenu
} while(!$Global:EndMenu)

stop-process -Id $PID

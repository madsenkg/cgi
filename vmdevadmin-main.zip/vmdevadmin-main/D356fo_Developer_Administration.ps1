﻿#Requires -RunAsAdministrator
Clear-Host;

function showmenu { 
   $prg = menu (Get-ChildItem -Filter D365_*.ps1) 
   Invoke-Expression ".//$prg"
 }

#Init Variables
$Global:EndMenu   = $false
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#load-module
Write-Output "loading modules.. please hold on..."
.\_D365_Load_Modules.ps1

 Do {
    Clear-Host;

    Write-Output "D365 Developer Administration"
    Write-Output "============================="

    showmenu
} while(!$Global:EndMenu)

stop-process -Id $PID
#Requires -RunAsAdministrator
cls;

#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\StartStopEnv_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:Version   = '1.0.0';

#Load modules
./_D365_load_modules.ps1

cls

Write-Output ("============================== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Start/Stop Environment {0} ........... =" -f $env:COMPUTERNAME)
Write-Output ("==================================================")
Write-Output ("Script version is.....: {0}" -f $Script:Version)
try {
    #Test if service is running
    $ServiceName = 'W3SVC'
    $arrService = Get-Service -Name $ServiceName
    
    Write-Output "Please wait..."
    Write-Host ""

    if ($arrService.Status -ne 'Running'){
        Write-Output "D365 Service is stopped, starting up environment..."
        Start-D365Environment -All 
        }
    Else{
        Write-Output "D365 Service is running, shutting down environment..."
        Stop-D365Environment -All
        }
    
}
catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    Start-Sleep 4        
}
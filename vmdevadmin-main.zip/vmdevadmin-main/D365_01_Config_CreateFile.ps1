﻿cls;
#Script version
$Script:Version = '1.0.0';
$Script:StorageAccountFile = 'storageaccount.config';

#Init Variables
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;

Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\CreateConfig_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

#Load assamblies
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null

try {

    Write-Output ("============================== {0} ====" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
    Write-Output ("= Create the Config file for the storage Account.. =")
    Write-Output ("====================================================")
    Write-Output ("Script version is.....: {0}" -f $Script:Version)

    $Ressource  = [Microsoft.VisualBasic.Interaction]::InputBox(“Enter the name of the Storage Account”, “Config-file”)
    $Key        = [Microsoft.VisualBasic.Interaction]::InputBox(“Paste in the one of the keys from the Storage Account”, “Config-file”)
    $Connection = [Microsoft.VisualBasic.Interaction]::InputBox(“Paste in the one of the connectionstrings from the Storage Account”, “Config-file”)
           
    if ($key -And $Ressource -and $Connection) {

        Write-Output ("Creating file : {0}" -f $Script:StorageAccountFile)
        
        New-Item $Script:StorageAccountFile -ItemType File -Force -Confirm
        Add-Content $Script:StorageAccountFile '<?xml version="1.0" encoding="utf-8"?>' 
        Add-Content $Script:StorageAccountFile '<accesskeys>'
        Add-Content $Script:StorageAccountFile ('    <ressource>{0}</ressource>' -f $Ressource)
        Add-Content $Script:StorageAccountFile ('    <key>{0}</key>' -f $Key)
        Add-Content $Script:StorageAccountFile ('    <connectionstring>{0}</connectionstring>' -f $Connection)
        Add-Content $Script:StorageAccountFile '</accesskeys>'
    } 
    else {
        throw "One of the values are missing"
    }

    Write-Output "File content:"
    Get-Content $Script:StorageAccountFile
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    start-sleep 2        
}
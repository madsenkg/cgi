Clear-Host;

#Script version
$Script:Version = '2.1.0';
$Script:StorageAccountFile = 'storageaccountV2.config';

#Init Variables
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;

Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\CreateConfig_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

#Load assamblies
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms') | Out-Null
[System.Reflection.Assembly]::LoadWithPartialName('MSystem.Drawing') | Out-Null

try {

    Write-Output ("================================ {0} ====" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
    Write-Output ("= Create the config file for the access to key vault =")
    Write-Output ("======================================================")
    Write-Output ("Script version is.....: {0}" -f $Script:Version)

#region begin formdesign

    $form = New-Object 'System.Windows.Forms.Form';$form.Width = 590;$form.Height = 250;$form.Text = 'Paste following values';$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen;
   
    ##############Define text label1
    $textLabel1 = New-Object 'System.Windows.Forms.Label';$textLabel1.Left =  25;$textLabel1.Top = 30;$textLabel1.Text = 'Directory ID (TenantId)';
    $textBox1   = New-Object 'System.Windows.Forms.TextBox';$textBox1.Left = 150;$textBox1.Top   = 30;$textBox1.width  = 400;$textBox1.PasswordChar;
    ##############Define text label2
    $textLabel2 = New-Object 'System.Windows.Forms.Label';$textLabel2.Left =  25;$textLabel2.Top = 70;$textLabel2.Text = 'Subscription ID';
    $textBox2   = New-Object 'System.Windows.Forms.TextBox';$textBox2.Left = 150;$textBox2.Top   = 70;$textBox2.width  = 400;
    ##############Define text label3
    $textLabel3 = New-Object 'System.Windows.Forms.Label';$textLabel3.Left =  25;$textLabel3.Top =110;$textLabel3.Text = 'Key vault name';
    $textBox3   = New-Object 'System.Windows.Forms.TextBox';$textBox3.Left = 150;$textBox3.Top   =110;$textBox3.width  = 400;
    ##############Define text label4
    $textLabel4 = New-Object 'System.Windows.Forms.Label';$textLabel4.Left =  25;$textLabel4.Top =150;$textLabel4.Text = 'Secret name';
    $textBox4   = New-Object 'System.Windows.Forms.TextBox';$textBox4.Left = 150;$textBox4.Top   =150;$textBox4.width  = 400;

    #############Define default values for the input boxes
     $defaultValue = ''
     $textBox1.Text = $defaultValue;
     $textBox2.Text = $defaultValue;
     $textBox3.Text = $defaultValue;
     $textBox4.Text = $defaultValue;
    
    #############define button
     $button = New-Object 'System.Windows.Forms.Button';
     $button.Left  = 450;
     $button.Top   = 180;
     $button.Width = 100;
     $button.Text  = 'Enter';
    
    ############# This is when you have to close the form after getting values
     $eventHandler = [System.EventHandler] {
        $textBox1.Text;
        $textBox2.Text;
        $textBox3.Text;
        $textBox4.Text;
        $form.Close();
    };
    
    $button.Add_Click($eventHandler) ;
    
    #############Add controls to all the above objects defined
     $form.Controls.Add($textLabel1);
     $form.Controls.Add($textBox1);
     $form.Controls.Add($textLabel2);
     $form.Controls.Add($textBox2);
     $form.Controls.Add($textLabel3);
     $form.Controls.Add($textBox3);
     $form.Controls.Add($textLabel4);
     $form.Controls.Add($textBox4);
     $form.Controls.Add($button);
     $form.ShowDialog();
    
    #################return values
    $azTenant       = $textBox1.Text
    $azSubscription = $textBox2.Text
    $azKeyValutName = $textBox3.Text
    $azSecretName   = $textBox4.Text

    #endregion
           
    if (!($azTenant -and $azSubscription -and $azKeyValutName -and $azSecretName)) {
            throw "One or more value(s) are missing !"
        }

    if ($azTenant -match '([A-Za-z0-9]+(-[A-Za-z0-9]+)+)' -eq $false ) {
        throw "Tenant ID is wrong format !"
    }

    if ($azSubscription -match '([A-Za-z0-9]+(-[A-Za-z0-9]+)+)' -eq $false) {
        throw "Subscription ID is wrong format !"
    }

    if ($azTenant -eq $azSubscription) {
        throw "Tenant and Subscription ID is the same ID !"
    }

    Write-Output ("Creating file : {0}" -f $Script:StorageAccountFile)
    Add-Content $Script:StorageAccountFile ('{')
    Add-Content $Script:StorageAccountFile ('   "accesskeys": {')
    Add-Content $Script:StorageAccountFile ('    "azTenant": "{0}",' -f $azTenant)
    Add-Content $Script:StorageAccountFile ('    "azSubscription": "{0}",' -f $azSubscription)
    Add-Content $Script:StorageAccountFile ('    "azKeyValutName": "{0}",' -f $azKeyValutName)
    Add-Content $Script:StorageAccountFile ('    "azSecretName": "{0}"' -f $azSecretName)
    Add-Content $Script:StorageAccountFile ('    }')
    Add-Content $Script:StorageAccountFile ('}    ')

    Write-Output "File content:"
    Get-Content $Script:StorageAccountFile
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

    Stop-Transcript
    start-sleep 5        
}

﻿Clear-Host;

#Script version
$Script:Version = '2.0.0';
$Script:StorageAccountFile = 'storageaccount.config';

#Init Variables
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;

Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\CreateConfig_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

#Load assamblies
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null

try {
    Write-Output ("================================ {0} ====" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
    Write-Output ("= Create the config file for the access to key vault =")
    Write-Output ("======================================================")
    Write-Output ("Script version is.....: {0}" -f $Script:Version)

    $azTenant       = [Microsoft.VisualBasic.Interaction]::InputBox(“Paste/Enter the tenant Id ”, “Config-file”)
    $azSubscription = [Microsoft.VisualBasic.Interaction]::InputBox(“Paste/Enter subscription Id”, “Config-file”)
    $azKeyValutName = [Microsoft.VisualBasic.Interaction]::InputBox(“Paste/Enter Key vault name”, “Config-file”)
    $azSecretName   = [Microsoft.VisualBasic.Interaction]::InputBox(“Paste/Enter Secret name”, “Config-file”)     

           
    if ($azTenant -and $azSubscription -and $azKeyValutName -and $azSecretName ) {

        Write-Output ("Creating file : {0}" -f $Script:StorageAccountFile)
        Add-Content $Script:StorageAccountFile ('{')
        Add-Content $Script:StorageAccountFile ('   "accesskeys": {')
        Add-Content $Script:StorageAccountFile ('    "azTenant": "{0}",' -f $azTenant)
        Add-Content $Script:StorageAccountFile ('    "azSubscription": "{0}",' -f $azSubscription)
        Add-Content $Script:StorageAccountFile ('    "azKeyValutName": "{0}",' -f $azKeyValutName)
        Add-Content $Script:StorageAccountFile ('    "azSecretName": "{0}"' -f $azSecretName)
        Add-Content $Script:StorageAccountFile ('    }')
        Add-Content $Script:StorageAccountFile ('}    ')
 
        } 
    else {
        throw "One of the values are missing !"
    }

    Write-Output "File content:"
    Get-Content $Script:StorageAccountFile
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    start-sleep 2        
}
﻿Clear-host;

#Script version
$Script:Version = '1.0.0';
$Script:StorageAccountFile = 'storageaccount.config';

#Init Variables
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;

Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\SetAdmin_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

#Load assamblies
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null

Function IsValidEmail { 
    Param ([string] $In) 
    # Returns true if In is in valid e-mail format. 
    [system.Text.RegularExpressions.Regex]::IsMatch($In, "^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
} 

$D365AdminEmail = [Microsoft.VisualBasic.Interaction]::InputBox(“Setting D365fo Administrator”, “Enter your email”)
$Valid = IsValidEmail($D365AdminEmail)

try {

    if (!($D365AdminEmail)) {
        throw "Email is missing !"
    }

    if (!($Valid)) {
        throw ("Email '{0}' is not valid !" -f $D365AdminEmail)
    }

    Write-Output ("Setting '{0}' to Admin" -f $D365AdminEmail)
    Set-D365Admin $D365AdminEmail
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    start-sleep 2        
}
﻿##Requires -RunAsAdministrator
Clear-Host;

$Script:StorageAccountFile = 'storageaccount.config';
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
    
#Script version
$Script:Version = '1.0.1';
   
#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\BackupAxDB_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

# Get Sql information
$Sql = Get-DbaDefaultPath -SqlInstance .
$backupFileName = ("{0}\{1}_AxDB_{2}.bak" -f $Sql.Backup, $env:COMPUTERNAME, (Get-Date -format "yyyyMMddhhmm"))

Write-Output ("============================== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Backup AxDB and export to Storage Account..... =")
Write-Output ("==================================================")
Write-Output ("Script version is.....: {0}" -f $Script:Version)
Write-Output ("SQL Server Instance...: {0}" -f $sql.SqlInstance)
Write-Output ("Backupfile is ........: {0}" -f $backupFileName)

try {
    if (Test-Path $Script:StorageAccountfile) {
        [xml]$ConfigFile = Get-Content $Script:StorageAccountFile
        $Ressource       = $ConfigFile.accesskeys.ressource;        
        $Key             = $ConfigFile.accesskeys.key;
    }
    else {
        throw "Storageaccount-file is missing, contact your tsa";
    }
    # Backup AxDB to SQL Backup folder
    Backup-DbaDatabase -SqlInstance $Sql.SqlInstance -FilePath $backupFileName -Database AxDB -Type Full -IgnoreFileChecks -copyOnly -compressBackup
    
    #Upload file to storageaccount folder
    Write-Output ("Uploading backup '{0}' to '{1}\backup'" -f $backupFileName, $Ressource);
    Invoke-D365AzureStorageUpload -AccountId $Ressource -AccessToken $Key -Container "backup" -FilePath $backupFileName -DeleteOnUpload
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    Start-Sleep 4        
}
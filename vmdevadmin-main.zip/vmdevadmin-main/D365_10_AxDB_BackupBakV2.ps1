﻿Clear-Host;

$Script:StorageAccountFile = 'storageaccount.config';
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
    
#Script version
$Script:Version = '2.0.0';
   
#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\BackupAxDB_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

# Get Sql information
$Sql = Get-DbaDefaultPath -SqlInstance .
$backupFileName = ("{0}\{1}_AxDB_{2}.bak" -f $Sql.Backup, $env:COMPUTERNAME, (Get-Date -format "yyyyMMddhhmm"))

Write-Output ("============================== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Backup AxDB and export to Storage Account..... =")
Write-Output ("==================================================")
Write-Output ("Script version is.....: {0}" -f $Script:Version)
Write-Output ("SQL Server Instance...: {0}" -f $sql.SqlInstance)
Write-Output ("Backupfile is ........: {0}" -f $backupFileName)

try {
    if (Test-Path $Script:StorageAccountfile) {
        $ConfigFile = Get-Content $Script:StorageAccountFile | ConvertFrom-Json
        $azTenant       = $ConfigFile.accesskeys.azTenant;        
        $azSubscription = $ConfigFile.accesskeys.azSubscription;
        $azKeyValutName = $ConfigFile.accesskeys.azKeyValutName;       
        $azSecretName   = $ConfigFile.accesskeys.azSecretName; 

        Write-Output ("Tenant ID is .........: {0}" -f $azTenant)           
        Write-Output ("Subscription ID is ...: {0}" -f $azSubscription)     
        
        #Sign in to Azure
        Write-output "Sign-in to Azure now..."

        Connect-AzureRMAccount -Tenant $azTenant -Subscription $azSubscription -WarningAction SilentlyContinue
        Set-AzureRMContext -Tenant $azTenant -Subscription $azSubscription -WarningAction SilentlyContinue
#       To use when Az is supported
#       Connect-AzAccount -Tenant $azTenant -Subscription $azSubscription
#       Set-AzContext -Tenant $azTenant -Subscription $azSubscription
		Write-output "Connected..."	

        #extract account and key from connectionstring
        #To use when Az is supported
        #$ConnectionString = Get-AzKeyVaultSecret -VaultName $azKeyValutName -Name $azSecretName -AsPlainText   
        $ConnectionStringTmp = Get-AzureKeyVaultSecret -VaultName $azKeyValutName -Name $azSecretName -WarningAction SilentlyContinue
        $ConnectionString = $ConnectionStringTmp.SecretValueText
        $ConnectionString = $ConnectionString.Replace('==','@@')

		$AzKeys = @()
        $AzKeys = $ConnectionString.Split(';') | ForEach-Object{$PSItem | ConvertFrom-Csv -Delimiter '=' -Header Name, Value}

        $StorageAccountName = $AzKeys[1].Value
        $StorageAccountKey = $AzKeys[2].Value.Replace("@@","==")

        #Write-Output ("Storage Account name .: {0}" -f $StorageAccountName)           
    }
    else {
        throw "Storageaccount-file is missing, contact your tsa";
    }

    # Backup AxDB to SQL Backup folder
    Backup-DbaDatabase -SqlInstance $Sql.SqlInstance -FilePath $backupFileName -Database AxDB -Type Full -IgnoreFileChecks -copyOnly -compressBackup
    
    #Upload file to storageaccount folder
    Write-Output ("Uploading backup '{0}' to '{1}\backup'" -f $backupFileName, $StorageAccountName);
    Invoke-D365AzureStorageUpload -WarningAction SilentlyContinue -AccountId $StorageAccountName -AccessToken $StorageAccountKey -Container "backup" -FilePath $backupFileName -DeleteOnUpload  
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Remove-Item -Path $backupFileName -Force -Confirm:$false -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    Start-Sleep 4        
}
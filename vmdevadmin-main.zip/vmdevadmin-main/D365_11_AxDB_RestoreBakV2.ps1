#Requires -RunAsAdministrator
Clear-Host;

#Script version
$Script:Version = '2.0.0';
$Script:StorageAccountFile    = 'storageaccount.config';
$Script:StorageContainerName  = 'backup';

[string]$DbName = ("AxDB_{0}" -f (Get-Date -Format MMMdd))

#Init Variables
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;

Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\RestoreAxDB_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

# Get Sqlserver information
$Sql = Get-DbaDefaultPath -SqlInstance .

try {

    if (!(Test-Path $Script:StorageAccountfile)) {
         throw "Storageaccount-file is missing, contact your tsa";
    }

    Write-Output ("============================== {0} =======" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
    Write-Output ("= Download file from storage account and Restore AxDB =")
    Write-Output ("=======================================================")
    Write-Output ("Script version is.....: {0}" -f $Script:Version)
    Write-Output ("SQL Server Instance...: {0}" -f $sql.SqlInstance)
    Write-Output ("Backup is restored as : {0}" -f $DbName)

    #Get values from StrorageAccount.config XML file
    $ConfigFile     = Get-Content $Script:StorageAccountFile | ConvertFrom-Json
    $azTenant       = $ConfigFile.accesskeys.azTenant;        
    $azSubscription = $ConfigFile.accesskeys.azSubscription;
    $azKeyValutName = $ConfigFile.accesskeys.azKeyValutName;       
    $azSecretName   = $ConfigFile.accesskeys.azSecretName; 

    Write-Output ("Tenant ID is .........: {0}" -f $azTenant)           
    Write-Output ("Subscription ID is ...: {0}" -f $azSubscription)     
        
    #Sign in to Azure
    Write-output "Sign-in to Azure now..."
    Connect-AzureRMAccount -Tenant $azTenant -Subscription $azSubscription -WarningAction SilentlyContinue
    Set-AzureRMContext -Tenant $azTenant -Subscription $azSubscription -WarningAction SilentlyContinue

#   To use when Az is supported
#   Connect-AzAccount -Tenant $azTenant -Subscription $azSubscription
#   Set-AzContext -Tenant $azTenant -Subscription $azSubscription
    Write-output "Connected..."	

    #extract account and key from connectionstring
    #To use when Az is supported
    #$ConnectionString = Get-AzKeyVaultSecret -VaultName $azKeyValutName -Name $azSecretName -AsPlainText    
    $ConnectionStringTmp = Get-AzureKeyVaultSecret -VaultName $azKeyValutName -Name $azSecretName -WarningAction SilentlyContinue
    $ConnectionString = $ConnectionStringTmp.SecretValueText
    $ConnectionString = $ConnectionString.Replace('==','@@')

    $AzKeys = @()
    $AzKeys = $ConnectionString.Split(';') | ForEach-Object{$PSItem | ConvertFrom-Csv -Delimiter '=' -Header Name, Value}

    $StorageAccountName = $AzKeys[1].Value
    $StorageAccountKey = $AzKeys[2].Value.Replace("@@","==")

    #Get blob context and create a list
    $ListBlobs = Get-D365AzureStorageFile -AccountId $StorageAccountName -AccessToken $StorageAccountKey -Container $Script:StorageContainerName -WarningAction SilentlyContinue

    #List blob files
    $BackupFileName = @($ListBlobs | Out-GridView -Title 'Choose a file' -PassThru) 
    Write-Output ("Restore database .....: {0}" -f $DatabasefileName)
        
    #Download selected file from Blob
    Write-Output ("Downloading backup '{0}' to '{1}' - Please wait" -f $BackupFileName.Name, $sql.Backup);
    Invoke-D365AzureStorageDownload -AccountId $StorageAccountName -Container $Script:StorageContainerName -AccessToken $StorageAccountKey -FileName $BackupFileName.Name -Path $sql.Backup -WarningAction SilentlyContinue
    
    #Find latest bak file in backup folder
    $DatabasefileName = Get-ChildItem -file -Path $sql.Backup -Filter *.bak | sort LastWriteTime | select -last 1

    if ($DatabasefileName) {
        Write-Output ("Restore database .....: {0}" -f $DatabasefileName)
    }
    else {
        throw "No file selected !"
    }

    Write-Output "Restoring - Please wait";
    Restore-DbaDatabase -SqlInstance $Sql.SqlInstance -Path $DatabasefileName -DatabaseName $DbName -DestinationFileSuffix (Get-Date -f "_ddMMyyyy")

    Stop-D365Environment

    Write-Output "Removing the old original database..."
    Remove-D365Database -DatabaseName AxDB_original

    Write-Output "Switching to the imported database..."
    Switch-D365ActiveDatabase -NewDatabaseName $DbName

    Write-Output "Update sysglobalconfiguration..."
    Invoke-D365SqlCmd -Command "UPDATE sysglobalconfiguration set value = 'SQLSERVER' where name = 'BACKENDDB'"
    Invoke-D365SqlCmd -Command "UPDATE sysglobalconfiguration set value = '0' where name = 'TEMPTABLEINAXDB'"
    Invoke-D365SqlCmd -Command "DELETE FROM ENUMVALUETABLE where ENUMVALUE > 250" 

    Write-Output "Starting the services..."
    Start-D365Environment

    Start-Sleep -Seconds 180

    Write-Output "Sync AXDB..."
    Invoke-D365DBSync -Verbosity Detailed -ShowOriginalProgress
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

    Stop-Transcript 
    Start-Sleep 4         
}

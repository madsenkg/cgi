﻿#Requires -RunAsAdministrator
cls;

#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\MaintenanceOnOff_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:Version   = '1.0.0';

#Load modules
./_D365_load_modules.ps1

cls

Write-Output ("============================== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Enable/Disable Maintenance Mode {0}  =" -f $env:COMPUTERNAME)
Write-Output ("==================================================")
Write-Output ("Script version is.....: {0}" -f $Script:Version)
try {
    #Test if maintenance mode is on 
    $MaintenanceMode = Get-D365MaintenanceMode | Select -ExpandProperty "MaintenanceModeEnabled"  # check maintenance mode
    
    Write-Output "Please wait..."
    Write-Host ("Status: {0}" -f $MaintenanceMode)

    if ($MaintenanceMode -eq $false){
        Write-Output "Maintenance Mode is OFF, enabling maintenance mode ..."
        Enable-D365MaintenanceMode -ShowOriginalProgress
        }
    Else{
        Write-Output "Maintenance Mode is ON, disabling maintenance mode ..."
        Disable-D365MaintenanceMode -ShowOriginalProgress
        }
}
catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    start-sleep 4       
}
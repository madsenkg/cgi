﻿#Requires -RunAsAdministrator
cls;

#Script version
$Script:Version = '1.0.0';

#Init Variables
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;

$Delimitor        = ','
$SqlFileName      = join-path $Script:ScriptDir '_SqlOptimizeTablesScript.sql'
$SqlScript        = @"
USE AxDB
GO

SET NOCOUNT ON;
DECLARE @objectid int;
DECLARE @indexid int;
DECLARE @partitioncount bigint;
DECLARE @schemaname nvarchar(130);
DECLARE @objectname nvarchar(130);
DECLARE @indexname nvarchar(130);
DECLARE @partitionnum bigint;
DECLARE @partitions bigint;
DECLARE @frag float;
DECLARE @allowpagelocked int;
DECLARE @command nvarchar(4000);
-- Conditionally select tables and indexes from the sys.dm_db_index_physical_stats function
-- and convert object and index IDs to names.
SELECT
    object_id AS objectid,
    index_id AS indexid,
    partition_number AS partitionnum,
    avg_fragmentation_in_percent AS frag
	
INTO #work_to_do
FROM sys.dm_db_index_physical_stats (DB_ID(), NULL, NULL , NULL, 'LIMITED')
WHERE avg_fragmentation_in_percent > 10.0;

-- Declare the cursor for the list of partitions to be processed.
DECLARE partitions CURSOR FOR SELECT * FROM #work_to_do;

-- Open the cursor.
OPEN partitions;

-- Loop through the partitions.
WHILE (1=1)
    BEGIN;
        FETCH NEXT
           FROM partitions
           INTO @objectid, @indexid, @partitionnum, @frag;
        IF @@FETCH_STATUS < 0 BREAK;
        SELECT @objectname = QUOTENAME(o.name), @schemaname = QUOTENAME(s.name)
        FROM sys.objects AS o
        JOIN sys.schemas as s ON s.schema_id = o.schema_id
        WHERE o.object_id = @objectid;
       
		SELECT @indexname = QUOTENAME(name), @allowpagelocked = sys.indexes.allow_page_locks
        FROM sys.indexes
        WHERE  object_id = @objectid AND index_id = @indexid;
        SELECT @partitioncount = count (*)
        FROM sys.partitions
        WHERE object_id = @objectid AND index_id = @indexid;
     
		-- 30 is an arbitrary decision point at which to switch between reorganizing and rebuilding.
        IF @frag < 30.0 
			BEGIN
				IF @allowpagelocked = 0
					BEGIN
						PRINT N'Table : ' + @objectname  +  N' Index : ' + @Indexname + N' is pagelocked ! Changed to rebuild';
						SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REBUILD';
					END
				ELSE
					SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REORGANIZE';
			END
        IF @frag >= 30.0
            SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REBUILD';
        IF @partitioncount > 1
            SET @command = @command + N' PARTITION=' + CAST(@partitionnum AS nvarchar(10));
		EXEC (@command)
        PRINT N'Executed: ' + @command;
    END;

-- Close and deallocate the cursor.
CLOSE partitions;
DEALLOCATE partitions;

-- Drop the temporary table.
DROP TABLE #work_to_do;
GO
"@

Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\SqlOptimizeAxDB_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

# Get Sqlserver information
$Sql = Get-DbaDefaultPath -SqlInstance .

try {
    Write-Output ("============================== {0} ====" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
    Write-Output ("= ReIndex / ReOrganzie the tables of AxDB          =")
    Write-Output ("====================================================")
    Write-Output ("Script version is.....: {0}" -f $Script:Version)
    Write-Output ("SQL Server Instance...: {0}" -f $sql.SqlInstance)
    
    Write-Output ("====================================================")    
    Write-Output "Stopping all services..."
    Stop-D365Environment -All
    Write-Output ("====================================================")    
    
    Write-Output "Generating SQL Script..."
    
    #Create SQL file
    Remove-Item -Path $SqlFileName -Force -Verbose -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    New-Item $SqlFileName -ItemType file -Force    

    #Generate Script
    Add-Content $SqlfileName $SqlScript

    #Execute SqlScript
    Write-Output " === SQL SCRIPT START ====================================================================="
    Get-Content $SqlFileName
    Write-Output " === SQL SCRIPT END ======================================================================="
    
    Write-Output "Executing the SQL Script..."
    Invoke-sqlcmd -ServerInstance $sql.SqlInstance -Database AxDB -InputFile $SqlFileName -SuppressProviderContextWarning -QueryTimeout 0 -Verbose
    
    Write-Output ("====================================================")    
    Write-Output "Starting the services..."
    Start-D365Environment
    Write-Output ("====================================================")    
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Remove-Item -Path $SqlFileName -Force -WarningAction Ignore -ErrorAction Ignore

    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript 
    Start-Sleep 5
}
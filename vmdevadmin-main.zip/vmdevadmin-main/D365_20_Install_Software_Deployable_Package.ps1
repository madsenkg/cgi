﻿#Requires -RunAsAdministrator
cls;

#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\InstallSDP_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))
$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:Version   = '1.0.1';

#Load modules
./_D365_load_modules.ps1;

cls;

#Is Visual Studio open then close it
if(get-process "Devenv" -ea SilentlyContinue){ 
    Write-Output "Visual Studio is open - Closing program!"    
    Stop-Process -processname "Devenv"
}

#Is your Box Synced?$Synced = [System.Windows.Forms.MessageBox]::Show("Have you synced your devbox with the branch ?","Install new package", "YesNo" , "Information" , "Button1")if (!$Synced) {    Write-Output ("Now sync your devbox!")    Stop-Transcript    Exit}#Select file to Unlock, unzip and install$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
    InitialDirectory = [Environment]::GetFolderPath('MyDocuments') 
    Filter = 'Zip files (*.zip)|'
    Title = "Open Software Deployable Package (*zip)"
    Multiselect = $false   
}

if (!$FileBrowser.ShowDialog()) {
    Write-Output "Aborting script"
    Stop-Transcript
    exit
}

$PackageFile = Get-ChildItem -Path $FileBrowser.FileName$PackageName = [System.IO.Path]::GetFileNameWithoutExtension($FileBrowser.FileName).Replace(" ","_")# "\W"
Write-Output ("============================== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Install Software Deployable package  ......... =")
Write-Output ("==================================================")
Write-Output ("Script version is.....: {0}" -f $Script:Version)
Write-Output ("Packagefile ..........: {0}" -f $PackageFile)

try {

    #Unblock file
    Unblock-File -Path $PackageFile -Verbose -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    
    $PackageFolder = (Join-Path $PackageFile.Directory ($PackageFile.BaseName -replace "\W"))

    if (Test-Path -Path $PackageFolder) {
        Remove-Item $PackageFolder -Recurse -Force -Verbose
    }

    #Extract zipfil
    Expand-Archive -LiteralPath $PackageFile -DestinationPath $PackageFolder
    
    #Make RunbookId
    [string]$RunbookId = ("RunBook_{0}_{1}" -f $PackageName, (Get-Date -format yyyyMMddHHmm))

    #Install package
    Invoke-D365SDPInstall -Path $PackageFolder -Command RunAll -ShowOriginalProgress -RunbookId $RunBookId 
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    Start-Sleep 5        
}
﻿#Requires -RunAsAdministrator
#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\DeployReports_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:Version   = '1.0.0';

cls;
Write-Output ("============================== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Deploy all SSRS Reports ...................... =")
Write-Output ("==================================================")
Write-Output ("Script version is.....: {0}" -f $Script:Version)

$Script:ScriptDir

try {
    Write-Output "Deploying reports - Please wait..."
    $scriptPath = "K:\AosService\PackagesLocalDirectory\Plugins\AxReportVmRoleStartupTask\DeployAllReportsToSsrs.ps1"
    $argumentList = @("-packageInstallLocation","K:\AosService\PackagesLocalDirectory")
    Invoke-Expression "& `"$scriptPath`" $argumentList"
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."
	Stop-Transcript
    Start-Sleep 5           
}
﻿#Requires -RunAsAdministrator
#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\ResetDatamart_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:Version   = '1.0.0';

cls;
Write-Output ("============================== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Reset Financial Reporting Datamart ........... =")
Write-Output ("==================================================")
Write-Output ("Script version is.....: {0}" -f $Script:Version)

try {
    Write-Output "Resetting datamart - Please wait..."
    $MRModulePath = "K:\MROneBox\MRInstallDirectory\Server\MRDeploy\"
    Import-Module (join-path $MRModulePath "MRDeploy.psd1") -Force
    Reset-DatamartIntegration -Reason OTHER -ReasonDetail ("Reset Datamart by '{0}'" -f $env:USERNAME) -SkipAXTableReset -Force    
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript        
}
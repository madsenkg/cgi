﻿#Requires -RunAsAdministrator
Clear-Host;
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null

#Init Variables
$Script:ScriptDir = Split-Path -Parent $PSCommandPath;
Set-Location $Script:ScriptDir;

#Start Transscript Log
Start-Transcript -Path (join-path $Script:ScriptDir ("Logs\CAR_{0}_{1}.log" -f $env:COMPUTERNAME,(Get-Date -format yyyyMMddHHmm)))

$Script:StopWatch = [System.Diagnostics.Stopwatch]::StartNew();  
$Script:Version   = '1.0.1';

Write-Output ("=============== {0} ==" -f (Get-Date -f "dd-MM-yyyy HH:mm"))
Write-Output ("= Generate CAR report ........... =")
Write-Output ("===================================")
Write-Output ("Script version is.....: {0}" -f $Script:Version)

# Get path to file
$Script:ConfigurationFile = Get-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Dynamics\AX\Development

$BinPath        = Split-path -Parent $Script:ConfigurationFile.DefaultConfig
$PackagesPath   = Split-path -Parent $BinPath

$DocsPath       = join-path $env:USERPROFILE "Documents"

$D365foModel      = [Microsoft.VisualBasic.Interaction]::InputBox(“Enter development model”, “D365fo Model”)
$D365foModule     = [Microsoft.VisualBasic.Interaction]::InputBox(“Enter development module”, “D365fo Module”)

$ParmMetaData     = ("-metadata={0}" -f $PackagesPath)
$ParmPackagesRoot = ("-packagesRoot={0}" -f $PackagesPath)
$ParmModel        = ("-model=""{0}""" -f $D365foModel)
$ParmModule       = ("-module=""{0}""" -f $D365foModel)
$ParmXmlLogPath   = ("-xmlLog={0}" -f (Join-Path $DocsPath "BPCheckLogcd.xml"))
$ParmExcelPath    = ("-car={0}" -f (Join-Path $DocsPath ("CAR_report_{0}.xlsx" -f (Get-Date -format yyyyMMddHHmm)))) 

$ParmArg          = (Join-Path $BinPath "xppbp.exe") + (" {0} -all {1} {2} {3} {4} {5}" -f $ParmMetaData, $ParmPackagesRoot, $ParmModel, $ParmModule, $ParmXmlLogPath, $ParmExcelPath) 
try {
    Write-Output "Creating report - Please wait..."
    #Create the command file
    $CARcmdFile = New-Item -Name "CARcommand.cmd" -ItemType "file" -Value $ParmArg -Force
    Write-Output ("Executing : {0}" -f $ParmArg)
  
    #Execute the command file
    Start-Process -FilePath $CARcmdFile -Wait
    
    #Remove the command file
    Remove-Item $CARcmdFile -Force
}

catch {
    Write-Output "Something went wrong ! "
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Warning ("{0} - {1}" -f $FailedItem, $ErrorMessage)
    exit
}

finally {
    Write-Output "-------"
    Write-Output ("Total time spend -> {0} " -f ($Script:StopWatch.Elapsed.ToString('hh\:mm\:ss')))
    Write-Output "Done ! Script Ended..."

	Stop-Transcript
    Invoke-Item $DocsPath        
}
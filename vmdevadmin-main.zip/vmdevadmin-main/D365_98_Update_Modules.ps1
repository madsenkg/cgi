﻿Clear-Host;

Write-Output "Updating modules... please wait..."
Update-Module -Name NuGet -Force
Update-Module -Name dbatools -Force
Update-Module -Name d365fo.tools -Force
Update-Module -Name ps-menu -Force
Write-Output "Modules are updated..."
Start-Sleep 4
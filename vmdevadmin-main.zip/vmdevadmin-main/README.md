# vmdevadmin
D365fo Scripts for developers administration

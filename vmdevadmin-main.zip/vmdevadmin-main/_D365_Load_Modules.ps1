﻿function Load-Module ($m) {

    # If module is imported say that and do nothing
    if (Get-Module | Where-Object {$_.Name -eq $m}) {
        write-host "Module $m is already imported."
    }
    else {

        # If module is not imported, but available on disk then import
        if (Get-Module -ListAvailable | Where-Object {$_.Name -eq $m}) {
	        Write-output ("Importing module : {0}..." -f $m)            
            Import-Module $m
        }
        else {
            # If module is not imported, not available on disk, but is in online gallery then install and import
            if (Find-Module -Name $m | Where-Object {$_.Name -eq $m}) {
                Write-output ("Installing and importing module : {0}..." -f $m)                  
                Install-Module -Name $m -Force -Scope AllUsers -AllowClobber
                Import-Module $m
            }
            else {

                # If module is not imported, not available and not in online gallery then abort
                write-host "Module $m not imported, not available and not in online gallery, exiting."
                #exit 1
            }
        }
    }
}
Set-PSRepository -Name "PSGallery" -InstallationPolicy Trusted

#Loading modules
Load-Module AzureRM
Load-Module NuGet
#Load-Module Az.accounts
#Load-Module Az.storage
#Load-Module Az.KeyVault
Load-Module dbatools
Load-Module d365fo.tools
Load-Module ps-menu